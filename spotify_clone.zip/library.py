@app.route('/add_to_library/<int:song_id>')
def add_to_library(song_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user_id = session['user_id']
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO library (user_id, song_id) VALUES (%s, %s)", (user_id, song_id))
    conn.commit()
    cursor.close()
    conn.close()
  
return redirect(url_for('index'))

@app.route('/library')
def library():
    if 'username' in session:
        # Get current user's id
        cursor.execute("SELECT id FROM users WHERE username=%s", (session['username'],))
        user = cursor.fetchone()
        user_id = user['id']

        # Fetch favorite songs of this user
        cursor.execute("""
            SELECT s.* FROM songs s
            JOIN favorites f ON s.id = f.song_id
            WHERE f.user_id = %s
        """, (user_id,))
        songs = cursor.fetchall()

        return render_template('library.html', songs=songs)
    else:
        return redirect(url_for('login'))
