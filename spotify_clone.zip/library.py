@app.route('/add_to_library/<int:song_id>')
def add_to_library(song_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user_id = session['user_id']
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO library (user_id, song_id) VALUES (%s, %s)", (user_id, song_id))
    conn.commit()
    cursor.close()
    conn.close()
    return redirect(url_for('index'))
