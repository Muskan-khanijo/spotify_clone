from flask import Flask, render_template, request, redirect, url_for, session, flash
import mysql.connector

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# MySQL connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="muskan@106",
    database="spotify_c7"
)
cursor = db.cursor(dictionary=True)

# Home route
@app.route('/')
def home():
    if 'username' in session:
        cursor.execute("SELECT * FROM songs")
        songs = cursor.fetchall()

        # Get favorite songs for logged-in user
        cursor.execute("SELECT song_id FROM favorites WHERE user_id = (SELECT id FROM users WHERE username=%s)", (session['username'],))
        fav_songs = [row['song_id'] for row in cursor.fetchall()]

        return render_template('index.html', songs=songs, user=session['username'], fav_songs=fav_songs)
    return redirect(url_for('login'))

# Signup
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        cursor.execute("SELECT * FROM users WHERE username=%s", (username,))
        if cursor.fetchone():
            flash("Username already exists!")
            return redirect(url_for('signup'))

        cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, password))
        db.commit()
        flash("Signup successful! Please login.")
        return redirect(url_for('login'))
    return render_template('signup.html')

# Login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        cursor.execute("SELECT * FROM users WHERE username=%s AND password=%s", (username, password))
        if cursor.fetchone():
            session['username'] = username
            return redirect(url_for('home'))
        flash("Invalid credentials!")
        return redirect(url_for('login'))
    return render_template('login.html')

# Logout
@app.route('/logout')
def logout():
    session.pop('username', None)
    flash("Logged out successfully!")
    return redirect(url_for('login'))

# Library route
@app.route('/library')
def library():
    if 'username' in session:
        cursor.execute("SELECT * FROM songs")
        songs = cursor.fetchall()

        cursor.execute("SELECT song_id FROM favorites WHERE user_id = (SELECT id FROM users WHERE username=%s)", (session['username'],))
        fav_songs = [row['song_id'] for row in cursor.fetchall()]

        return render_template('library.html', songs=songs, user=session['username'], fav_songs=fav_songs)
    return redirect(url_for('login'))

# Toggle favorite
@app.route('/add_favorite', methods=['POST'])
def add_favorite():
    if 'username' not in session:
        flash("Login required!")
        return redirect(url_for('login'))

    user = session['username']
    song_id = request.form['song_id']

    # Get user ID
    cursor.execute("SELECT id FROM users WHERE username=%s", (user,))
    user_id = cursor.fetchone()['id']

    # Check if already favorite
    cursor.execute("SELECT * FROM favorites WHERE user_id=%s AND song_id=%s", (user_id, song_id))
    if cursor.fetchone():
        cursor.execute("DELETE FROM favorites WHERE user_id=%s AND song_id=%s", (user_id, song_id))
        db.commit()
        flash("Removed from favorites")
    else:
        cursor.execute("INSERT INTO favorites (user_id, song_id) VALUES (%s, %s)", (user_id, song_id))
        db.commit()
        flash("Added to favorites")

    return redirect(request.referrer)



if __name__ == '__main__':
    app.run(debug=True)
