
CREATE DATABASE spotify_c7;
USE spotify_c7;

-- 2. Users table for login/signup
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL
);
INSERT INTO users(id, username, password)
VALUES('103' , 'Muskan' , 'mmuusskkaann'),
('104' , 'Sania' , 'ssaanniiaa'),
('105', 'Keshav' , 'kkeesshhaavv'),
('106', 'Rahul' , 'rraahhuull');
select* from users;

CREATE TABLE songs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    artist VARCHAR(100) NOT NULL,
    filename VARCHAR(100) NOT NULL,
    image VARCHAR(255)
);

INSERT INTO songs (title, artist, filename, image) VALUES 
('Without Me', 'AP Dhillon', 'songs/Without Me.mp3','covers/Ap Dhillon.jpg'),
('Mahiya', 'Diljit', 'songs/Mahiya.mp3', 'covers/diljit.jpg'),
('Tu', 'Talwinder', 'songs/Tu.mp3', 'covers/Talwinder.jpg'),
('Take It Easy' , 'Karan Aujla' , 'songs/Take it Easy.mp3', 'covers/Karan Aujla.jpg');
select * from songs;

DROP TABLE IF EXISTS favorites;

CREATE TABLE favorites (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    song_id INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (song_id) REFERENCES songs(id)
);

insert into favorites(user_id, song_id)
values(104, 2);
select * from favorites;