const songs = document.querySelectorAll('.song');
const searchInput = document.getElementById('searchInput');
const audioPlayer = document.getElementById('audioPlayer');
const coverImg = document.getElementById('cover');
const currentSong = document.getElementById('currentSong');
const artistName = document.getElementById('artistName');

function playSong(songSrc, coverSrc, title, artist) {
    audioPlayer.src = songSrc;
    coverImg.src = coverSrc;
    currentSong.textContent = title;
    artistName.textContent = artist;
    audioPlayer.play();
}

searchInput.addEventListener('input', () => {
    const query = searchInput.value.toLowerCase();
    songs.forEach(song => {
        const title = song.querySelector('h3').textContent.toLowerCase();
        const artist = song.querySelector('p').textContent.toLowerCase();
        song.style.display = (title.includes(query) || artist.includes(query)) ? 'flex' : 'none';
    });
});

